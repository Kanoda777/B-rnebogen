import { base44 } from './base44Client';


export const Child = base44.entities.Child;

export const Story = base44.entities.Story;

export const SharedStory = base44.entities.SharedStory;

export const Rating = base44.entities.Rating;



// auth sdk:
export const User = base44.auth;